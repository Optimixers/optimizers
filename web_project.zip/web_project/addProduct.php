<?php
session_start();

?>

<!-- ================================================ -->
<?php

if (isset($_SESSION['productadded'])){
	$product_added=$_SESSION['productadded'];
	unset ($_SESSION['productadded']);
	echo "<div style=font-weight:bold; font-size:20px;><b>$product_added</b></div>";
}
	
$login="";

if (isset($_SESSION['login'])){
	$login=$_SESSION['login'];
}

if ($login=="login"){  ?>
<!DOCTYPE html>
<html>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
*{
	position:static;
	}
	#full-page a{
		color:#E76AEF;
		}
		#header-bottom-menu a {
    font-family: Franklin Gothic Demi;
    color: #787070;
    font-style: oblique;
    font-size: 22px;
    font-weight: bolder;
    padding-bottom: 10px;
}

.container {
    overflow: hidden;
    background-color: #1abc9c;
    font-family: Arial;
}

.container a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}



.container a:hover {
    background-color: black;
}



 a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

 a:hover {
    background-color: black;
}

body,h1 {font-family: "Raleway", Arial, sans-serif}
h1 {letter-spacing: 6px}
.w3-row-padding img {margin-bottom: 12px}
</style>
<body>

<!-- !PAGE CONTENT! -->
<div class="w3-content" style="max-width:1500px">

<!-- Header -->
<header class="w3-panel w3-center w3-opacity" style="padding:128px 16px">
 
  <div class="container">
  <a href="welcomepage.php">Home</a>
    <a href="addProduct.php">Add Products</a>
  <a href="viewProducts.php">View Products</a>
  <a href="logout.php">Log Out</a>
</div>

</header>

<form action="productProcess.php" method="post" enctype="multipart/form-data">
    
      
    
    &nbsp; &nbsp; Product Name
    <input type="text" name="productName" value="" placeholder="Product Name" required><br><br><br>
    
    
    
  
    &nbsp; &nbsp; Product Price
    <input type="number" name="productPrice" value="" placeholder="Product Price" required><br><br><br>
    
    
    
  
    &nbsp; &nbsp; Product Code
    <input type="text" name="productCode" value="" placeholder="Product Code" required><br><br><br>
    
    
    
  
    &nbsp; &nbsp; Product In Stock:
    <select name="productInStock">
    	<option value="No">In Stock</option>
    	<option value="Yes">Yes</option>
       	<option value="No">No</option>
     
    
    </select>
    <br><br><br>
    

  &nbsp; &nbsp; Product Discount
       <input type="number" name="productDiscount" value="" placeholder="Product Discount" required><br><br><br>
    
       
   &nbsp; &nbsp; Product Sizes
    
        
        
  <input type="text" name="productSizes" value="" placeholder="Product Sizes" required><br><br><br>
    
    
    
      &nbsp; &nbsp; Product Details
    
        
      
    &nbsp; &nbsp; <input type="text" name="productDetails" value="" placeholder="Product Details" required><br><br><br>
    
    </b>
    
    &nbsp; &nbsp; <input type="file" name="file" id="image" required ><br></br>
    
    &nbsp; &nbsp; <input  type="submit" name="submit" value="submit">
    
</form>
<!-- ================================================ -->



<?php

}
else{
	
	header ("Location: login.php");}

?>

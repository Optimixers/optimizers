<?php

require("./requires/connection.php");
?>
<!-- ================================================ -->

<?php
$userID = $_POST['userID'];

$userName = $_POST['userName'];
$userPassword = $_POST['userPassword'];

$sqlinsert = "UPDATE users SET userName='$userName',userPassword='$userPassword' where userId='$userID'";


$result = mysqli_query($connection,$sqlinsert);
 
if(!$result)
{
  die('Could not enter data: ' . mysql_error());
}
?>
 <script> location.replace("viewUsers.php"); </script>
	//header("Location: viewUsers.php?status=yes");
<!-- ================================================ -->



<?php

session_start();
?>
<!-- ================================================ -->

<?php

	
include("./requires/connection.php");

if (isset($_GET['id'])){
	var_dump($_GET['add']);
	die;
	}

$productName = $_POST['productName'];
$productPrice = $_POST['productPrice'];
$productCode = $_POST['productCode'];
$productInStock = $_POST['productInStock'];
$productDiscount = $_POST['productDiscount'];
$productSizes = $_POST['productSizes'];
$productDetails = $_POST['productDetails'];

$newadd="";
	if(isset($_POST['submit'])){
    $name       = $_FILES['file']['name'];  
    $temp_name  = $_FILES['file']['tmp_name'];
	$name2=$productName.$name;  
	//var_dump($name2);
	//die;
    if(isset($name)){
        if(!empty($name)){      
            $location = 'images/';     
			
            if(move_uploaded_file($temp_name, $location.$name2)){
                echo 'File uploaded successfully';
				$newadd=$productName.$_FILES['file']['name'];
			}
            
        }       
    }  else {
        echo 'You should select a file to upload !!';
    }
}


$sqlinsert = "insert into products (productName,productPrice,productCode,productInStock,ProductDiscount,ProductSizes,ProductDetails,imageAddress)  values ('$productName','$productPrice','$productCode','$productInStock', '$productDiscount','$productSizes', '$productDetails','$newadd')";



$result = mysqli_query($connection,$sqlinsert);
 


	$_SESSION['add']="add"; 
	?>
	 <script> location.replace("viewProducts.php"); </script>
<?php
	//header("Location: addProduct.php?id=yes");









?>
<!-- ================================================ -->



<?php
session_start();

?>
<html>
    <head>
        
        <style>
h1{
	text-align: center;	
}

table{
	border:2px solid black;
	background-color: light blue;
	margin:0 auto;
}
th{
	border-bottom:5px solid black;
}
td{
	border-bottom: 2px solid blue;
}
</style>
</head>   
    <br><br><br>
</html>

<!-- ================================================ -->
<?php
include("./requires/connection.php");
$login="";

if (isset($_SESSION['login'])){
	$login=$_SESSION['login'];
}
	
if ($login=="login"){
$query = "SELECT * FROM users";
$result = mysqli_query($connection,$query);
if (!$result)
{
    die ("Error");
}
echo "<table>";
echo "<tr><th>User ID</th><th>User Name</th><th>User Password</th><th>Edit</th><th>Delete</th></tr>";

while ($row = mysqli_fetch_array($result)){
	
	
	
    
    echo "<tr><td>";
    echo $row['userID'];
    echo "</td>";
    
    echo "<td>";
    echo $row['userName'];
    echo "</td>";
    
    echo "<td>";
    echo $row['userPassword'];
    echo "</td>";
   
    
    echo "<td>";
    echo '<a href="editUser.php?id=' . $row['userID'] . '">Edit</a></td>';
    
    echo "<td>";
    echo '<a href="deleteUser.php?id=' . $row['userID'] . '">Delete</a></td>';
}
echo "</table>";
echo "<br><br>";
?>
<html>
<body>
	<a href="logout.php"><center><input type="button" value="logout"> </center></a><br><br><br>
</body>

</html>
<!-- ================================================ -->

<?php

}
else {
	?>
	 <script> location.replace("login.php"); </script>
<?php
}
//	header ("Location: login.php");}
?>

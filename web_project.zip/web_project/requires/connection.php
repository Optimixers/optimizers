<?php


$servername = "localhost";
$username 	= "root";
$password 	= "";
$dbname 	= "project";

// Create connection
$connection = mysqli_connect($servername, $username, $password,$dbname);
// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_error());
    
} 
 else {
echo'CONNECTED';    
}

$mydatabase = mysqli_select_db($connection,$dbname) ; 

if(!$mydatabase) 
    die("Database Selection failed"  .mysqli_error() );
else
    echo 'SELECTED';

?>
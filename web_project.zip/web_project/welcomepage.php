<?php
session_start();

if (isset($_SESSION['login'])){
	if ($_SESSION['login']=="login"){
		
		
		
?>

<!DOCTYPE html>
<html>
<head>
<style>

*{
	position:relative;
	}
.container {
    overflow: hidden;
    background-color: #1abc9c;
    font-family: Arial;
}

.container a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}


.container a:hover {
    background-color:black;
}


 a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}
 a:hover {
    background-color: black;
}

</style>
</head>
<body>
<br><br><br>
<h1 style="text-align:center; font-size:50px;">Welcome</h1>
<br><br><br>
<div class="container">
  <a href="welcomepage.php">Home</a>
    <a href="addProduct.php">Add Products</a>
  <a href="viewProducts.php">View Products</a>
  <a href="logout.php">Log Out</a>
    

</div>
<?php
}
	}
	else{
		?>
	 <script> location.replace("login.php"); </script>
<?php
	


		//header ("Location: login.php");
		}

?>

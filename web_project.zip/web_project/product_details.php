<head>
<style>
#product_detail{
	height:340px;
	width:100%;
	font-size:20px;
	color:white;
	}
#product_left{
	width:350px;
	height:100%;
	float:left;
	}	
#product_right{
	width:800px;
	height:100%;
	float:left;

	}	
	</style>
</head>
<body>
<br><br><br><br>
</body>

<?php
if (isset($_GET)){
	include("./requires/connection.php");

	$id = $_GET['id'];
	}
	
	$query = "SELECT * FROM products where productID='$id'";
$result = mysqli_query($connection,$query);
if (!$result)
{
    die ("Error");
}
echo "<div id='product_detail'>";
echo "<div id='product_left'>";
while ($row = mysqli_fetch_array($result)){
	
	echo "<img src=\"images/".$row['imageAddress']."\"width=300 height=300 /></div>";
	
	echo "<div><b>Product Details:</b>$row[productDetails]<br><br><br>
            	<b>Product Code:</b>$row[productCode]<br><br><br>
            	<b>Product in Stock:</b>$row[productInStock]<br><br><br>
            	<b>Product Discount:</b>$row[productDiscount]<br><br><br>
            	<b>Available Sizes:</b>$row[productSizes]<br></div><br>";
?>

<div>
          <br><br><br>
          </div>
          </div>

<?php
}


?>

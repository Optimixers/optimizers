<?php
require("./requires/connection.php");
if (isset($_GET['id']))
{
	$id = $_GET['id'];
	$dbselect = "DELETE FROM users WHERE userID= '".$id."';";
	
	$res= mysqli_query($connection, $dbselect) or die ('Error');
	?>
    
    
	 <script> location.replace("viewUsers.php"); </script>
<?php
	//header("Location: viewUsers.php?status=yes");
	
}


?>
<?php
require_once './views/footer.php';
?>

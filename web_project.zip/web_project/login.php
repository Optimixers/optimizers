<?php

session_start();

include("./requires/connection.php");


if (isset($_SESSION['msg']))
{
	echo $_SESSION['msg'];
	unset ($_SESSION['msg']);
}

if (isset($_POST['submit']))
{
	
	$_SESSION['userName'] = $_POST['user'];
	$_SESSION['userPassword'] = $_POST['pass'];
	
	header ("Location: loginProcess.php");
}
	
?>

<html>
<head>
		 <title>admin</title>
		 <meta charset="utf-8">
		 <link rel="stylesheet" type="text/css" href="loginasadminstyle.css">

</head>
<body>
<div class="body">
       
         
			
            		
		<div id="adminpanel">
		<div><b><h1>ADMIN PANEL</h1></b></div>
		<form method="post" action="" id="form">
		Admin Username:<input style = "    width: 50%;
    margin-left: 2%;
    height: 30px;
    border-radius: 3px;
    border-color: black;"type="text" name="user" required="required"><br><br>

		Admin Password:<input style = "    width: 50%;
    margin-left: 2%;
    height: 30px;
    border-radius: 3px;
    border-color: black;"type="password" name="pass" required="required"><br><br>
		<input type="reset" id ="reset" name="reset" value="RESET">
		<input type="submit" id="submit" name="submit" value="SUBMIT"><br><br>
		
		</form>
		</div>
</div>
</body>


</html>